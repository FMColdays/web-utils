# @fmcoldays/post-action

Ejecuta peticiones HTTP al hacer click en cualquier elemento con
`data-action-url`. Soporta confirmación, loading state, actualización de targets
en el DOM, notificaciones, descarga de archivos y redirección.

```bash
pnpm add @fmcoldays/post-action notiflix
```

> `notiflix` es una `peerDependency` (la provee tu app). Inyecta sus propios estilos por JS, no requiere CSS aparte.

## Uso

**Opción A — auto (un solo import, sin llamar nada):**

```ts
import '@fmcoldays/post-action/auto'
```

**Opción B — manual (control sobre cuándo/dónde registrar):**

```ts
import { registerPostAction } from '@fmcoldays/post-action'

registerPostAction() // una vez al arrancar la app; devuelve fn para desregistrar
```

```html
<button type="button"
        data-action-url="/api/items/42"
        data-action-method="DELETE"
        data-action-confirm="true"
        data-action-reload="true">
  Eliminar
</button>
```

## Atributos

| Atributo | Default | Descripción |
|---|---|---|
| `data-action-url` *(req.)* | — | URL de la petición. |
| `data-action-method` | `POST` | Método HTTP. |
| `data-action-body` | — | Body JSON literal. En GET → query string. |
| `data-action-body-form` | — | Selector de `<form>` → FormData. |
| `data-action-pick` | — | Mapa `{ campo: selector }` resuelto al click. |
| `data-action-csrf` | — | Incluye token CSRF. |
| `data-action-confirm` | — | Diálogo de confirmación (Notiflix). |
| `data-action-confirm-title` / `-msg` | — | Textos del diálogo. |
| `data-action-disable` | — | Deshabilita el trigger durante la petición. |
| `data-action-loading-class` | — | Clases CSS añadidas al trigger mientras carga. |
| `data-action-target` | — | Selector donde inyectar la respuesta. |
| `data-action-target-prop` | `html` | `html` \| `text` \| `value`. |
| `data-action-download` | — | Trata la respuesta como archivo descargable. |
| `data-action-silent` | — | Suprime notificaciones. |
| `data-action-success-msg` / `-error-msg` | — | Mensajes de éxito/error. |
| `data-action-reload` | — | Recarga la página tras éxito. |
| `data-action-redirect` | — | Redirige tras éxito (prioridad sobre reload). |
| `data-action-then` | — | Hace click en otro elemento tras éxito. |

## Notas

- Funciona en cualquier elemento clickeable. Para checkbox/radio el estado se togglea tras el éxito.
- `redirect` y `reload` son excluyentes (`redirect` gana). `download` y `target` son excluyentes.

## Estructura

```
src/
├── index.ts                    # barril + registerPostAction
├── register.ts                 # listener (event delegation)
├── handle-post-action-click.ts # orquestador del ciclo completo
├── types/                      # ActionOptions, ActionResult
├── helpers/                    # options, dom, notify, download, server-message
└── services/                   # request.service (fetch + shared.buildHttpPayload)
```
