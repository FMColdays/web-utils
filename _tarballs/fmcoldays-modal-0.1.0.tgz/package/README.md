# @fmcoldays/modal

Carga vistas parciales Razor en un `<dialog id="dialog-form">` vía AJAX.
Auto-detecta header, footer, formularios multi-paso, select2 y validación
unobtrusive de MVC.

```bash
pnpm add @fmcoldays/modal jquery
```

> `jquery` es una `peerDependency`. select2 y jQuery Unobtrusive Validation se
> usan si están presentes como globales (igual que en el proyecto original).

## Uso

**Opción A — auto (un solo import, sin llamar nada):**

```ts
import '@fmcoldays/modal/auto'
```

**Opción B — manual:**

```ts
import { registerModal } from '@fmcoldays/modal'

registerModal() // habilita data-modal-url + window.openModal
```

```html
<!-- GET con parámetros dinámicos -->
<button data-modal-url="/SensorData/IndexAlertas"
        data-modal-pick='{"id": "#id_caja", "fecha": "#fecha"}'>
  Ver alertas
</button>
```

Programático:

```ts
import { openModal } from '@fmcoldays/modal'
openModal('/Controller/Action', { method: 'POST', bodyJson: '{"id":42}', csrf: true })
```

## Atributos del trigger

| Atributo | Default | Descripción |
|---|---|---|
| `data-modal-url` *(req.)* | — | Endpoint que devuelve la vista parcial. |
| `data-modal-method` | `POST` si hay body, `GET` si no | Método HTTP. |
| `data-modal-body` | — | Body JSON estático. En GET → query string. |
| `data-modal-body-form` | — | Selector de `<form>` → FormData. |
| `data-modal-pick` | — | Mapa `{ campo: selector }` resuelto al click. |
| `data-modal-csrf` | — | Incluye token CSRF. |

## Secciones de la vista parcial

| Atributo | Propósito |
|---|---|
| `data-modal-header` | Encabezado; se mueve al slot `[data-modal-slot="header"]`. |
| `data-modal-footer` | Pie con botones; se mueve fuera del scroll. |
| `data-step-form` + `data-step="N"` | Formulario multi-paso (wizard). |
| `select2-modal` | Inicializa select2 con `dropdownParent` correcto. |

## Estructura

```
src/
├── index.ts            # barril + registerModal
├── register.ts         # listener + window.openModal
├── open-modal.ts       # fetch ($.ajax) + render
├── const/              # selectores del dialog
├── types/              # ModalOptions + ambient d.ts (jquery plugins, window)
├── templates/          # error.template
└── utils/              # build-ajax-options, render-layout, init-select2,
                        # init-step-form, init-footer-submit, parse-unobtrusive
```
